package protocol // import "v2ray.com/core/common/protocol"

//go:generate go run v2ray.com/core/common/errors/errorgen
